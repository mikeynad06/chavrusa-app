# Handoff: ChavrusaApp

## Overview
ChavrusaApp is a free platform where people post a request to learn something (a masechta, a sefer, ten minutes of mussar) and another person **claims** it. No matching algorithm, no compatibility score — a bulletin board with a memory. Subscribers get notified when a request matching their topics / level / radius is posted.

Covered here: landing page (3 hero takes), About, Haskamas, Dashboard of open requests, Post-a-request form, Login, and a logo direction sheet.

## About the design files
The .dc.html files in this bundle are **design references written in HTML** — prototypes showing intended look and behavior. They are **not production code to copy**. support.js is a preview runtime for the prototype format; do not port it.

The task is to **recreate these designs in the target codebase's existing environment** (the brief mentions React + Vite — use whatever actually exists) with its established router, form handling, component patterns and libraries. If no environment exists yet, pick an appropriate stack and implement there.

## Fidelity
**High fidelity.** Colors, typography, spacing, radii and copy are final-intent; recreate pixel-close using the codebase's own primitives. The only lofi elements are image placeholders (diagonal-striped boxes with monospace captions) marking where real photography goes.

## Design tokens

### Color
| Token | Hex | Use |
|---|---|---|
| bg | #faf7f0 | page background (parchment) |
| surface | #fffdf8 | cards, inputs |
| surface-sunken | #f4eee0 | tinted panels, tag chips |
| surface-alt | #f0e9d9 | hover fills, number badges |
| border | #e3dbc9 | default hairline border |
| border-strong | #cdc2a8 | secondary button borders, filled inputs |
| ink | #1c1917 | primary text, dark sections, primary button |
| ink-2 | #292524 | long-form body copy |
| ink-muted | #57534e | secondary text |
| brass | #8a6a3c | primary accent, CTA fill, Hebrew text |
| brass-dark | #6f5430 | accent hover, link color, small labels |
| brass-light | #a58d64 | accent text on dark backgrounds |
| on-dark | #f4eee0 / #e8dfcc / #fffdf8 | text on #1c1917 |
| neutral-on-dark | #a8a29e | footer text |

Selection highlight #e8dfcc. Card shadow `0 1px 2px rgba(28,25,23,0.04)`. Card inside a dark section: background `rgba(232,223,204,0.05)`, border `1px solid rgba(232,223,204,0.2)`.

### Typography
- **Spectral** (serif; 400/500/600/700 + italic 400) — all headings, pull quotes (italic), stat numbers, wordmark.
- **Figtree** (sans; 400/500/600/700) — body, UI, buttons, labels.
- **Frank Ruhl Libre** (400/500) — all Hebrew, always with dir="rtl".
- **IBM Plex Mono** (400/500) — eyebrows, meta, badges, placeholder captions; typically 11–12.5px, uppercase, letter-spacing 0.1–0.14em.

Scale: h1 `clamp(32–42px, 4.4–7vw, 48–76px)`, line-height 1.03–1.1, weight 600, letter-spacing −0.02 to −0.025em; h2 `clamp(26px, 3.2vw, 40px)`; h3 20–23px; body 15–19px at line-height 1.55–1.75; labels 13px/600; meta 11–13.5px. Headlines use `text-wrap: balance`, paragraphs `text-wrap: pretty`.

### Spacing and shape
Page gutter 24px. Content max-width 1180px (wide), 900px (haskamas), 780–860px (prose). Section padding 64–96px vertical. Radii: pills 999px (all buttons, chips, filters), cards 14–20px, inputs 10px, small chips 6–9px. Grid gaps 14–28px.

### Layout primitive
Nearly every grid is `repeat(auto-fit, minmax(MIN, 1fr))` — fully fluid, zero media queries. Keep it that way. Text-bearing cards must never get fixed heights. RTL depends on logical properties (margin-inline-start, border-inline-start, padding-inline-start) — do not introduce left/right equivalents.

## Screens

### 1. Prototype control bar
Dark strip pinned above the navbar with hero-take switches and page jumps. **Prototype scaffolding only — do not build it.**

### 2. Navbar (sticky)
`position: sticky; top: 0`, background `rgba(250,247,240,0.92)`, `backdrop-filter: blur(10px)`, bottom border #e3dbc9. Inner row max-width 1180px, padding 16px 24px, flex, gap 24px, wraps.
- Left: logo mark (30x26 two-book mark, see Logo) plus "Chavrusa" in Spectral 21px/600, letter-spacing −0.01em.
- Right: text nav buttons — Home, About, Haskamas, Log in — padding 10px 14px, radius 999px, 14.5px. Inactive: transparent background and border, weight 500. Active: background #f4eee0, border #e3dbc9, weight 600. Hover background #f0e9d9.
- Then a primary pill "Dashboard": background and border #1c1917, text #faf7f0, padding 10px 20px, 14px/600; hover background and border #8a6a3c.

### 3. Landing — hero, three takes
Three alternatives are shown. **Pick one for production; A is the default and the recommendation.**

**A · Editorial (centered).** Padding 96px 24px 88px, text-align center, background `radial-gradient(120% 90% at 50% 0%, #fffdf8 0%, #faf7f0 60%, #f4eee0 100%)`, bottom border #e3dbc9, inner max-width 900px.
- Eyebrow pill: mono 12px uppercase, letter-spacing .12em, color #6f5430, background #f0e9d9, border #e3dbc9, padding 7px 14px, radius 999px — "Learn with someone · 1,240 pairs made".
- H1 Spectral `clamp(42px,7vw,76px)` / 1.03 / 600: "Nobody should have to learn alone."
- Hebrew line beneath, dir rtl, Frank Ruhl `clamp(20px,3vw,28px)`, brass.
- Sub: `clamp(17px,2vw,20px)` / 1.6, #57534e, max-width 620px: "Post what you want to learn — a masechta, a sefer, ten minutes of mussar. Someone claims it, and you have a chavrusa by the end of the week."
- Buttons (flex, gap 12, centered, margin-top 34px): primary "Post a request" — background and border #8a6a3c, text #fffdf8, padding 15px 28px, radius 999px, 16px/600, hover #6f5430. Secondary "Browse requests" — transparent, border #cdc2a8, text #1c1917, hover background #f0e9d9.
- Three sample-request chips: mono 12.5px, background #fffdf8, border #e3dbc9, radius 8px, padding 8px 13px.

**B · Product (split).** Two columns `auto-fit minmax(320px,1fr)`, gap 56px, padding 72px 24px 80px, background `linear-gradient(180deg,#fffdf8,#faf7f0)`. Left: mono eyebrow "Open requests, right now", H1 `clamp(38px,5.2vw,62px)` "Someone is waiting to learn the same thing you are.", 18px sub, two CTAs (Browse primary, Post secondary), mono note "Average time to a claim: 2 days". Right: two stacked request cards, the second offset by margin-inline-start 28px, plus a dashed #cdc2a8 row on #f4eee0 reading "14 more open in your area / See all".

**C · Quote-led.** Full-width dark band #1c1917, padding 88px 24px 76px, centered, max-width 860px: the Hebrew pasuk in Frank Ruhl `clamp(30px,5.4vw,54px)` / 1.35 in #fffdf8; Spectral italic `clamp(20px,2.8vw,28px)` #e8dfcc translation "And acquire for yourself a friend."; mono uppercase #a58d64 "Pirkei Avos 1:6". Below, on parchment: H1 `clamp(34px,4.6vw,52px)` "A chavrusa is the one thing you can't learn without.", 18px sub, same two CTAs.

The client said real quotes and sources are still coming — treat the Pirkei Avos attribution as swappable content.

### 4. Landing — How it works
Max-width 1180px, padding 84px 24px. H2 "How it works" and 17px sub "Three steps, and then it's between the two of you." Three cards `auto-fit minmax(260px,1fr)` gap 28px: background #fffdf8, border #e3dbc9, radius 16px, padding 28px. Each has a 38x38 circular badge (background #f0e9d9, border #e3dbc9, mono 15px #6f5430) reading 01 / 02 / 03, an H3 in Spectral 23px, and body at 15.5px / 1.6 #57534e.
1. **Post a request** — "Topic, level, style, when you're free, and whether you want to meet in person or learn over the phone."
2. **Someone claims it** — "Anyone browsing can take your request. Subscribers get a note the moment something in their area or interest goes up."
3. **Start learning** — "You get each other's details and set a first seder. We stay out of the way after that."

### 5. Landing — photo grid ("In the beis medrash")
Background #fffdf8, top border, padding 76px 24px. Mono eyebrow plus H2 "Chavrusas, mid-shakla v'tarya." Grid `auto-fit minmax(220px,1fr)`, `grid-auto-rows: 190px`, gap 14px; the first tile spans 2 columns and 2 rows. Each tile: radius 16px, border #e3dbc9, placeholder fill `repeating-linear-gradient(135deg,#f4eee0 0 10px,#faf7f0 10px 20px)`, caption chip bottom-left in mono 11.5–12px on #fffdf8 with border and radius 7–8px. Captions: two learners over an open gemara / hands on a page / shtender, early morning / learning by phone / shelf of sefarim. **Replace with real photography; per the brief, avoid identifiable faces where possible.**

### 6. Landing — Haskamas teaser (dark)
Section background #1c1917, text #f4eee0, padding 76px 24px. Header row: the Hebrew word for haskamas in Frank Ruhl 22px #a58d64 above H2 "With rabbinic endorsement." in #fffdf8, with a right-aligned link "Read all haskamas" in #e8dfcc 14.5px/600. Three quote cards `auto-fit minmax(270px,1fr)` gap 20px, radius 16px, padding 26px: Spectral italic 18px / 1.6 quote, name 14.5px/600 #fffdf8, title 13.5px #a58d64.

### 7. Landing — Subscriptions
Background #f4eee0, `border-block: 1px solid #e3dbc9`, padding 72px 24px, two columns `auto-fit minmax(300px,1fr)` gap 48px. Left: mono eyebrow "Subscriptions", H2 "Tell us what you'd say yes to.", 16.5px body. Right: card #fffdf8, radius 16px, padding 24px — mono uppercase label "Notify me about", then three space-between rows separated by a 1px #f0e9d9 divider (not after the last): "Gemara · b'iyun" (on), "Within 10 miles of Passaic" (on), "Anything on Sunday mornings" (off). Toggle: 40x22 pill, on #8a6a3c, off #e3dbc9, 16px #fffdf8 knob inset 3px.

### 8. Landing — Testimonials
Max-width 1180px, padding 84px 24px, three blockquotes `auto-fit minmax(280px,1fr)` gap 28px. Each: `border-inline-start: 2px solid #8a6a3c`, padding-inline-start 20px, Spectral italic 21px / 1.5 quote, footer 14px #57534e — "Yitzchok M. · Cleveland", "R' Dovid S. · Jerusalem", "Shani R. · Toronto".

### 9. About
Hero: max-width 780px, padding 84px 24px 72px, background `linear-gradient(180deg,#fffdf8,#faf7f0)`, bottom border. Mono eyebrow "About us", H1 `clamp(36px,5vw,58px)` "It started because one person couldn't find a chavrusa.", 19px / 1.65 lede.
Body: max-width 780px, padding 72px 24px — two paragraphs at 17.5px / 1.75 in #292524, a 260px-tall striped placeholder captioned "photo: two people learning together", then three value blocks `auto-fit minmax(200px,1fr)` gap 28px: "Free, and staying free", "Every level", "Quietly run".

### 10. Haskamas page
Hero centered, max-width 900px: the Hebrew word for haskamas at `clamp(26px,4vw,40px)` in brass, H1 "Haskamas" at `clamp(32px,4.4vw,48px)`, 17.5px sub "Rabbanim who reviewed the platform and encouraged its use in their communities."
List: max-width 900px, flex column, gap 20px. Each entry: background #fffdf8, border #e3dbc9, radius 18px, padding 34px, grid `auto-fit minmax(220px,1fr)` gap 30px with the quote column spanning 2 tracks.
- Left column: 74px circular striped portrait placeholder, name in Spectral 22px, role at 14.5px #57534e, Hebrew name in Frank Ruhl 17px brass.
- Right column: Spectral 19px / 1.65 #292524 quote, then a 150x44 signature line (bottom border 1px #cdc2a8, mono 10.5px caption "signature") and a mono uppercase brass Hebrew date ("Elul 5785", "Adar 5785").
- The third, short haskama uses a compact variant: background #f4eee0, quote plus one attribution line, no portrait.
Names used: Rabbi Aharon Weiss (Rosh Kollel, Kollel Ohr Yisroel), Rabbi Shmuel Brenner (Rav, Kehillas Bais Avrohom), Rabbi Eliyahu Kanner (Maggid Shiur, Yeshiva Nachlas Torah). **All haskama text and names are placeholders — real ones must be supplied.**

### 11. Dashboard — open requests
Max-width 1180px, padding 40px 24px 84px.
- Header row (space-between, wraps): H1 `clamp(28px,3.4vw,38px)` "Open requests" with 15.5px sub "{count} waiting for a chavrusa · 3 near you"; on the right a brass pill "Post a request" (padding 13px 24px, 15px/600).
- Filter row: flex, gap 8, wraps, margin 26px 0 24px, padding-bottom 22px, bottom border #e3dbc9. Chip variants — **all/active**: background #1c1917, text #fffdf8, 13.5px/600; **selected facet**: background #8a6a3c, text #fffdf8, with a × at 0.7 opacity; **idle**: background #fffdf8, border #e3dbc9, text #57534e. All radius 999px, padding 8px 14px. Facets shown: All topics · Level: any · Passaic, NJ ✕ · Within 10 miles ▾ · In person or online · Language: either · Sort: newest.
- Card grid: `repeat(auto-fill, minmax(320px,1fr))`, gap 18px.

**Request card.** Background #fffdf8, border #e3dbc9, radius 16px, padding 22px, flex column, shadow `0 1px 2px rgba(28,25,23,0.04)`, `transition: box-shadow 200ms, transform 200ms` (intent: subtle lift on hover).
- Top row: title in Spectral 21px/600 with the Hebrew title below it (dir rtl, Frank Ruhl 16px brass); optional badge on the right — mono 10.5px uppercase, letter-spacing .08em, #6f5430 on #f0e9d9, border #e3dbc9, radius 999px, nowrap; hidden entirely when empty.
- Note: 14.5px / 1.55 #57534e, margin-top 12px.
- Tag row (gap 7, wraps, margin-top 14px): level, when, where, language — 12.5px #6f5430 on #f4eee0, radius 6px, padding 5px 10px.
- Footer (margin-top 20px, padding-top 16px, top border #f0e9d9, space-between): a 32px initials avatar (background #f0e9d9, border #e3dbc9, 12.5px/600 #6f5430) plus poster name at 13.5px; on the right the claim button — padding 9px 18px, radius 999px, 14px/600, background and border #1c1917, text #faf7f0.
- **Claimed state:** card background becomes #f4eee0 and border #cdc2a8; button becomes transparent with border #cdc2a8 and text #6f5430, label "Claimed by you" (Hebrew: נלקח). In the prototype this is local optimistic state; production needs auth gating, a confirm / contact-exchange step, and an unclaim path.

Seed data (topic / Hebrew / note / level / when / where / language / poster / initials / badge):
1. Bava Metzia · בבא מציעא · "Second perek b'iyun. Learned it once before — want to go slower this time." · Intermediate · Nights · Online · English · Yosef T. · YT · New
2. Chumash with Rashi · חומש עם רש״י · "Total beginner. Hoping to get through the parsha each week before Shabbos." · Beginner · Sun AM · Lakewood, NJ · English · Meir K. · MK · Near you
3. Mesilas Yesharim · מסילת ישרים · "Fifteen minutes of mussar before shacharis. Consistency over depth." · Any · Early AM · Phone · Either · R' Dovid S. · DS · (no badge)
4. Daf Yomi — chazara · דף יומי · "I hear the shiur but never review it. Looking for someone in the same boat." · Intermediate · Motzei Shabbos · Online · Either · Ari L. · AL · (no badge)
5. Hilchos Shabbos · הלכות שבת · "Going through Mishna Berura from the start. Slow and thorough." · Advanced · Thu nights · Passaic, NJ · Either · Shloimy G. · SG · Near you
6. Pirkei Avos · פרקי אבות · "Would love to learn with a beginner and help them get comfortable." · Teaching · Flexible · Online · Hebrew · R' Yaakov F. · YF · Offering

Note: row 5's Hebrew in the prototype is misspelled (הלכות שבבת); the correct spelling is הלכות שבת.

### 12. Post a request (ChavrusaPost.dc.html)
Parchment page, padding 40px 24px 72px. Max-width 1080px, grid `auto-fit minmax(300px,1fr)` gap 32px, align-items start; the form card spans 2 tracks, the sidebar takes 1.

Form card: #fffdf8, border #e3dbc9, radius 20px, padding 32px. Mono eyebrow "Step 1 of 1", H1 Spectral 34px "Post a request", 15.5px sub "Say what you want to learn. Someone claims it, and we hand over your details." Fields, in order:
1. **What do you want to learn?** — full-width text input, padding 13px 15px, radius 10px, background #faf7f0, 15.5px; border #cdc2a8 for the filled/focused state, #e3dbc9 otherwise. Helper below in mono 11.5px brass: "A masechta, a sefer, or just something in mussar".
2. **Level** — single-select pill group: Beginner / Intermediate (selected: #1c1917 background, #fffdf8 text, 600) / Advanced / I want to teach. Padding 9px 15px, radius 999px, 13.5px.
3. **Style** and **Language** — two selects side by side (`auto-fit minmax(200px,1fr)`, gap 18px). Shell: padding 13px 15px, radius 10px, border #e3dbc9, background #faf7f0, 15px, value left and a ▾ in #a58d64 right. Values "B'iyun" and "English or Hebrew".
4. **When are you free?** — day multi-select grid `auto-fit minmax(88px,1fr)` gap 7px, Sun–Fri, centered 13px, radius 9px; selected days (Mon, Wed) get #8a6a3c background and #fffdf8 600 text. Then time-of-day pills: Early morning / Midday / Nights, with Nights selected in brass.
5. **Where** — two radio cards `auto-fit minmax(150px,1fr)` gap 10px, radius 12px, padding 14px: "In person / Meet somewhere local" (selected: border #1c1917, background #f4eee0) and "Online / phone / Anywhere in the world" (idle: border #e3dbc9, background #faf7f0). Below: location input ("Passaic, NJ") and radius select ("Within 10 miles").
6. **Anything else?** — 3-row textarea, `resize: vertical`, same input styling.
Footer (margin-top 26px, padding-top 22px, top border #f0e9d9, flex gap 12, wraps): primary "Post request" (brass, padding 14px 28px, 15.5px/600), secondary "Save draft" (border #cdc2a8, hover background #f4eee0), and a mono 11.5px brass note "Visible to 34 subscribers in your area".

Sidebar (flex column, gap 16):
- **Live preview** card (#fffdf8, radius 16px, padding 22px): mono uppercase label, then a miniature of the dashboard request card built from the current form values. This should be genuinely bound to form state in production.
- **What makes a request get claimed** card (background #f4eee0): Spectral 18px heading and a three-item list at 14px / 1.65 — "Name a specific sefer or perek", "Give two or three real time slots", "Say if you're fine learning by phone".

### 13. Login (ChavrusaLogin.dc.html)
Two panels, grid `auto-fit minmax(340px,1fr)`, min-height 620px, stacking on narrow screens.
Left (parchment, padding 64px 40px, vertically centered, inner max-width 400px): mono eyebrow "Welcome back", H1 Spectral 38px "Log in", Hebrew subline in Frank Ruhl 19px brass. Email input (placeholder you@example.com) and password input — full width, radius 10px, border #e3dbc9, background #fffdf8, 15px; a 12.5px "Forgot?" link baseline-aligned with the Password label. Primary full-width "Log in": padding 15px, radius 999px, background and border #1c1917, text #faf7f0, hover #8a6a3c. Divider: two 1px #e3dbc9 rules flanking a mono uppercase "or" in #a58d64. Then "Continue with Google" (background #fffdf8, border #cdc2a8) and "Send me a magic link" (transparent, #57534e, weight 500). Footer 14px: "New here? Create an account — takes a minute."
Right (background #1c1917, padding 64px 40px, flex column, gap 28): the Hebrew pasuk in Frank Ruhl 30px / 1.4 #fffdf8; Spectral italic 19px #e8dfcc translation; mono uppercase #a58d64 "Pirkei Avos 1:6". A 200px striped placeholder captioned "photo: beis medrash at night" using `rgba(232,223,204,0.06)` stripes. Three stats in a wrapping row — Spectral 26px #fffdf8 value over a 13px #a58d64 label: 1,240 pairs made · 2 days average to a claim · Free and staying that way.

### 14. Logo directions (ChavrusaLogo.dc.html)
A reference sheet, not a product screen. Three marks, each built from plain rectangles (no SVG in the prototype):
- **A · Two sefarim, leaning in** (recommended; this is the navbar mark): two rectangles side by side — left #8a6a3c rotated −8deg with transform-origin bottom right and radius `6px 2px 2px 6px`; right #1c1917 rotated 8deg with origin bottom left and radius `2px 6px 6px 2px`. Display size 36x58 inside a 78x66 box; navbar size 14x22 inside 30x26 with radius `3px 1px 1px 3px` and ±7deg rotation.
- **B · Open sefer, two pages** — two 40x44 blocks with `skewY(∓11deg)` and a 3px #6f5430 spine down the centre.
- **C · Ches monogram** — 72px #1c1917 rounded square (radius 18px) holding a ches in Frank Ruhl 500 at 40px #f4eee0, with a 3px brass bar near the bottom edge. Best as an app icon.
Lockups shown for A: horizontal on light (mark plus Spectral 28px "Chavrusa"), vertical on dark (brass and cream mark, #fffdf8 wordmark, Hebrew wordmark in #a58d64), and monochrome at 24px and 16px.
**A production logo should be redrawn properly as SVG by a designer** — the rectangle construction is a prototype approximation.

### 15. Footer
Background #1c1917, text #a8a29e, padding 44px 24px, max-width 1180px, space-between and wrapping: "Chavrusa" in Spectral 18px #e8dfcc; links About / Haskamas / Dashboard at 14px (hover #e8dfcc); mono 11.5px "Free to use · always".

## Interactions and behavior
- **Navigation**: the prototype holds a single page state (landing / about / haskamas / dash / login / post / logo) and scrolls to top on change. In production these are real routes — suggested: `/`, `/about`, `/haskamas`, `/requests`, `/requests/new`, `/login`.
- **Scroll reveal**: sections marked with a reveal attribute animate once on entering the viewport via IntersectionObserver at threshold 0.1 — opacity 0 to 1 and translateY 18px to 0, **620ms `cubic-bezier(.22,.68,0,1)`**, fill mode both, then unobserved. Honour `prefers-reduced-motion` in production; the prototype does not.
- **Hover states** are specified per component above; buttons and cards transition in ~200ms.
- **Claim** flips the card to its claimed state immediately (optimistic).
- **Language toggle** — see Bilingual below.
- **Not yet designed, needed for production**: loading and skeleton states, dashboard empty state, form validation errors, post-submit confirmation, the notification/subscription settings screen, request expiry and re-post.

## Bilingual and RTL
Decision from the brief: a **global language toggle**, real bilingual UI rather than decorative Hebrew.
- Toggling flips `dir` on the app root between ltr and rtl and swaps every UI string. All directional spacing already uses logical properties — keep it that way.
- Hebrew source text (masechta names, haskamas heading, pesukim) always renders in Frank Ruhl Libre with dir rtl **regardless of the UI language**.
- Strings currently paired: Home / בית · About / אודות · Haskamas / הסכמות · Dashboard / לוח בקשות · Log in / כניסה · Post a request / פרסום בקשה · Browse requests / עיון בבקשות · Claim / אני מעוניין · Claimed by you / נלקח. Everything else still needs translation — wire this to a real i18n library rather than the prototype's inline helper.

## State
| State | Shape | Notes |
|---|---|---|
| route | string | replace with the router |
| lang | "en" or "he" | drives dir and all strings; persist per user |
| requests | array (see seed data) | server-fetched, filterable |
| claimed | map of id to boolean | replace with server truth |
| filters | topic, level, location, radius, modality, language, sort | all URL-serializable |
| revealed | per section | view-only animation flag |

## Assets
No binary assets. Every image placeholder is a CSS `repeating-linear-gradient(135deg, …)` stripe pattern with a monospace caption naming the shot needed:
- beis medrash grid: two learners over an open gemara · hands on a page · shtender, early morning · learning by phone · shelf of sefarim
- About: two people learning together
- Login: beis medrash at night
- Haskamas: three portrait circles and three signature images

Fonts are Google Fonts — Spectral, Figtree, Frank Ruhl Libre, IBM Plex Mono. Self-host them for production.

## Files in this bundle
- `ChavrusaApp.dc.html` — navbar, footer, landing (3 hero takes), About, Haskamas, Dashboard, plus the page-switch and language logic
- `ChavrusaPost.dc.html` — post-a-request form with live preview sidebar
- `ChavrusaLogin.dc.html` — login split screen
- `ChavrusaLogo.dc.html` — logo directions and lockups
- `support.js` — preview runtime for the prototype format; **not** production code
- `ORIGINAL_BRIEF.md` — the original product brief

Open any of the .dc.html files directly in a browser. In ChavrusaApp the dark top strip switches hero takes and jumps between screens.

## Open items for the client
1. Real haskama text, rabbanim names, and signature images.
2. Real quotes and sources for the landing page (the client said these are coming).
3. Photography that respects modesty norms — user photos stay optional, initials avatars are the fallback everywhere.
4. Choose one hero take (A recommended) and one logo direction (A recommended).

