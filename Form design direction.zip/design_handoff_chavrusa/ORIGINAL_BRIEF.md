# ChavrusaApp — Design Brief

## What this is
ChavrusaApp is a platform that matches people for Torah study partnerships ("chavrusas"). A user posts what they want to learn (topic, level, style, timing, location or online), and other users can browse open requests and "claim" one to become someone's study partner. There's also a subscription system — users get notified when a new request matching their interests/location goes up.

## Pages that need design direction
1. **Landing page** — public, first impression, needs to explain the concept quickly and feel inviting rather than corporate. Will use scroll-based animation (Framer Motion) and likely feature quotes (about Torah study, chavrusa relationships, etc.).
2. **About Us** — the story/mission behind the platform.
3. **Haskamas** (rabbinic endorsements) — a page displaying endorsements/approvals from rabbis or community figures. Likely needs a layout for displaying names/titles/quotes/possibly photos or signatures in a dignified way.
4. **Navbar / global layout** — persistent across all pages: logo, nav links, a login/dashboard button in the corner.
5. **Dashboard** — the core logged-in experience: a feed of open study requests as cards, plus a way to post a new request and claim others' requests.

## Technical constraints (already decided, not up for debate)
- Built with **Tailwind CSS** utility classes — avoid designs that need heavy custom CSS beyond what Tailwind's design tokens support.
- **Framer Motion** available for animation — scroll-triggered reveals, transitions, etc. are all feasible.
- **Lucide React** is the icon set in use — assume icons come from this set, not custom illustrations, unless we discuss otherwise.
- Frontend is React + Vite; components need to be realistic to hand off to a React codebase, not just static mockups.

## What I don't have decided yet (please ask me about these)
- Overall visual tone/mood (e.g. warm and traditional vs. clean and modern vs. editorial/magazine-like vs. something else)
- Color palette — no colors have been chosen yet
- Typography direction — no fonts chosen yet
- How "religious/traditional" vs. "modern/secular-feeling" the visual language should be, given the Torah-study subject matter
- Whether Hebrew text/RTL support needs visual consideration (the platform has a `Language` field with English/Hebrew/Either, so this may matter)
- Light mode only, dark mode only, or both
- Reference sites, apps, or brands whose aesthetic I like (I don't have specific ones in mind yet — feel free to propose a few directions with examples)
- How prominent user photos/avatars should be, if at all
- Logo — doesn't exist yet; open to discussing whether it's text-based, symbolic, etc.

## Goal for this conversation
Please ask me guiding questions — one or a few at a time, not all at once — to help narrow down the visual direction above (tone, palette, typography, RTL, etc.), and then propose a design direction I can react to before we build out full mockups of the Landing page, About page, Haskamas page, and the shared Navbar/layout.
